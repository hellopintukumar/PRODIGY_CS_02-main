<h1><b>Cross And Nought</b><h1>
<p><h3>Made The Popular Game Tic Tac Toe Using HTML,CSS and JavaScript.<br>
It is Available now in Multiplayer version,But i will soon add the Single Player Feature Too.</h3></p>
<img src="https://github.com/Akash-Gupta-Sudo/Tic-Tac-Toe/blob/master/GameImg.png">
Live at: https://akash-gupta-sudo.github.io/Tic-Tac-Toe/
